document.getElementById("signupForm").addEventListener("submit", function (event) {
    event.preventDefault();

    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;

    const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    if (!emailPattern.test(email)) {
        alert("Silakan masukkan alamat email yang valid dengan domain.");
        return;
    }

    const passwordPattern = /^(?=.*[a-z])(?=.*[A-Z]).{8,}$/;
    if (!passwordPattern.test(password)) {
        alert("Kata sandi harus terdiri dari minimal 8 karakter dan terdiri dari huruf besar dan huruf kecil.");
        return;
    }

    alert("Formulir berhasil dikirim!");
    window.location.href = 'Login.html';
});

document.getElementById("showPassword").addEventListener("change", function () {
    const passwordField = document.getElementById("password");
    passwordField.type = this.checked ? "text" : "password";
});
