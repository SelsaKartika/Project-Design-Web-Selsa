const translations = {
    "id": {
        "welcome": "Selamat Datang",
        "intro": "Ide dan inspirasi memasak kreatif.",
        "goal": "Tujuan kami adalah menyederhanakan memasak sehari-hari untuk komunitas Indonesia, membuatnya menyenangkan dan menginspirasi.",
        "featuredRecipes": "Resep Unggulan",
    },
    "en": {
        "welcome": "Welcome",
        "intro": "Creative Cooking Ideas and Inspiration.",
        "goal": "Our goal is to simplify everyday cooking for Indonesian communities, making it fun and inspiring.",
        "featuredRecipes": "Featured Recipes",
    }
};
function switchLanguage(lang) {
    document.getElementById("welcome").innerText = translations[lang].welcome;
    document.getElementById("intro").innerText = translations[lang].intro;
    document.getElementById("goal").innerText = translations[lang].goal;
    document.getElementById("featuredRecipes").innerText = translations[lang].featuredRecipes;
}

let currentIndex = 0;
function moveSlide(step) {
    const slides = document.querySelector('.slider');
    const totalSlides = document.querySelectorAll('.slide').length;
    currentIndex = (currentIndex + step + totalSlides) % totalSlides;
    slides.style.transform = `translateX(-${currentIndex * 100}%)`;
}