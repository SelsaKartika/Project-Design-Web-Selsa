const translations = {
    "id": {
        "welcome": "Selamat Datang Chef",
        "intro": "Kumpulan resep kuliner nusantara bintang 5",
        "cta": "Daftar Sekarang! Buatlah resepmu menjadi viral",
        "registerButton": "Daftar Disini",
        "indonesianRecipes": "Resep Indonesia",
        "sliderText": [
            { "title": "Ikhlas & Berbagi!", "content": "Promo besar di akhir tahun, hanya di toko elektronik kami." },
            { "title": "Diskon Spesial!", "content": "Dapatkan harga terbaik untuk setiap pembelian barang elektronik." },
            { "title": "Jangan Lewatkan!", "content": "Ayo beli sekarang dan nikmati berbagai keuntungan menarik!" }
        ]
    },
    "en": {
        "welcome": "Welcome Chef",
        "intro": "A collection of 5-star Indonesian culinary recipes",
        "cta": "Sign Up Now! Make your recipe go viral",
        "registerButton": "Register Here",
        "indonesianRecipes": "Indonesian Recipes",
        "sliderText": [
            { "title": "Sincere & Sharing!", "content": "Big year-end promotions, only at our electronics store." },
            { "title": "Special Discount!", "content": "Get the best prices on every electronic purchase." },
            { "title": "Don't Miss Out!", "content": "Buy now and enjoy a variety of exciting benefits!" }
        ]
    }
};

function switchLanguage(lang) {
    const translation = translations[lang];

    document.querySelector("h2").innerText = translation.welcome;
    document.querySelector("p:nth-of-type(1)").innerText = translation.intro;
    document.querySelector("p:nth-of-type(2)").innerText = translation.cta;
    document.querySelector(".register-btn").innerText = translation.registerButton;
    document.querySelector("h3").innerText = translation.indonesianRecipes;

    const slides = document.querySelectorAll(".slide");
    translation.sliderText.forEach((text, index) => {
        const slide = slides[index];
        if (slide) {
            slide.querySelector("h2").innerText = text.title;
            slide.querySelector("p").innerText = text.content;
        }
    });
}

function moveSlide(direction) {
}
