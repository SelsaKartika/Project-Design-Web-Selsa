const translations = {
    "id": [
        { "link": "./Resep indonesia/nasigoreng.html" },
        { "link": "./Resep Korea/Tteokbokki.html" },
        { "link": "./Resep western/fishandchips.html" }
    ],
};

    const recipeCards = document.querySelectorAll(".recipe-card");
    translation.recipes.forEach((recipe, index) => {
        const card = recipeCards[index];
        if (card) {
            const link = card.querySelector("a");
            link.href = recipe.link;
            link.querySelector("h4").innerText = recipe.title;
            link.querySelector("p").innerText = recipe.description;
        }
    });
